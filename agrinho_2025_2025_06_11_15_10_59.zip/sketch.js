function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let fazendeiro;
let vegetais = [];
let pontuacao = 0;
let tempoVegetal = 1000; // Tempo em milissegundos para um novo vegetal aparecer
let ultimoVegetalTempo = 0;
let velocidadeFazendeiro = 5;

// Classe para o Fazendeiro
class Fazendeiro {
  constructor(x, y, tamanho) {
    this.x = x;
    this.y = y;
    this.tamanho = tamanho;
    this.cor = color(139, 69, 19); // Marrom
  }

  mostrar() {
    fill(this.cor);
    rect(this.x, this.y, this.tamanho, this.tamanho);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= velocidadeFazendeiro;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += velocidadeFazendeiro;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= velocidadeFazendeiro;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += velocidadeFazendeiro;
    }

    // Limites da tela
    this.x = constrain(this.x, 0, width - this.tamanho);
    this.y = constrain(this.y, 0, height - this.tamanho);
  }
}

// Classe para o Vegetal
class Vegetal {
  constructor(x, y, tamanho) {
    this.x = x;
    this.y = y;
    this.tamanho = tamanho;
    this.cor = color(random(0, 255), random(0, 255), random(0, 255)); // Cor aleatória para cada vegetal
    this.tempoVida = 3000; // Tempo em milissegundos que o vegetal fica na tela
    this.nascimento = millis();
  }

  mostrar() {
    fill(this.cor);
    ellipse(this.x + this.tamanho / 2, this.y + this.tamanho / 2, this.tamanho);
  }

  // Verifica se o vegetal deve sumir
  deveSumir() {
    return millis() - this.nascimento > this.tempoVida;
  }
}

function setup() {
  createCanvas(600, 400);
  fazendeiro = new Fazendeiro(width / 2 - 25, height / 2 - 25, 50);
  rectMode(CORNER); // Define o modo de desenho do retângulo para o canto superior esquerdo
}

function draw() {
  background(139, 204, 102); // Cor de grama para o fundo

  // Gera novos vegetais
  if (millis() - ultimoVegetalTempo > tempoVegetal) {
    let x = random(width - 30);
    let y = random(height - 30);
    vegetais.push(new Vegetal(x, y, 30));
    ultimoVegetalTempo = millis();
  }

  // Atualiza e mostra o fazendeiro
  fazendeiro.mover();
  fazendeiro.mostrar();

  // Atualiza e mostra os vegetais
  for (let i = vegetais.length - 1; i >= 0; i--) {
    let vegetal = vegetais[i];
    vegetal.mostrar();

    // Colisão entre fazendeiro e vegetal
    if (
      fazendeiro.x < vegetal.x + vegetal.tamanho &&
      fazendeiro.x + fazendeiro.tamanho > vegetal.x &&
      fazendeiro.y < vegetal.y + vegetal.tamanho &&
      fazendeiro.y + fazendeiro.tamanho > vegetal.y
    ) {
      pontuacao++;
      vegetais.splice(i, 1); // Remove o vegetal colhido
    } else if (vegetal.deveSumir()) {
      vegetais.splice(i, 1); // Remove o vegetal que sumiu por tempo
    }
  }

  // Exibe a pontuação
  fill(0);
  textSize(24);
  text("Pontuação: " + pontuacao, 10, 30);
}